import pandas as mypd
# creating a DataFrame from a dictionary of lists
mydict = {'myname': ['Saurabh', 'Yathartha', 'Priyanka', 'Princess'],
        'myage': [36, 2, 31, 3],
        'mycountry': ['India', 'NewZealand', 'Russia', 'Canada']}
mypd_dataframe = mypd.DataFrame(mydict)
print(mypd_dataframe)
print('-'*50)

# creating a DataFrame from a list of dictionaries
mylist = [{'myname': 'Saurabh', 'myage': 36, 'mycountry': 'India'},
        {'myname': 'Yathartha', 'myage': 2, 'mycountry': 'NewZealand'},
        {'myname': 'Priyanka', 'myage': 31, 'mycountry': 'Russia'},
        {'myname': 'Princess', 'myage': 3, 'mycountry': 'Canada'}]
my_pd_dataframe2 = mypd.DataFrame(mylist)
print(my_pd_dataframe2)
print(my_pd_dataframe2.ndim)
print(my_pd_dataframe2.shape)
#print(help(mypd.DataFrame))
print('-'*50)
# creating a DataFrame from a dictionary of series objects
myname = mypd.Series(['Saurabh', 'Yathartha', 'Priyanka', 'Princess'])
myage = mypd.Series([36, 2, 31, 3])
mycountry = mypd.Series(['India', 'NewZealand', 'Russia', 'Finland'])
mypd_dataframe = mypd.DataFrame({'myname':myname,'myage':myage,'mycountry':mycountry})
print(mypd_dataframe)