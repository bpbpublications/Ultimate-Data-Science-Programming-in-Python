import pandas as mypd
# creating a Pandas Series from a list
mylist = [101, 102, 103, 104, 105]
mypd_series = mypd.Series(mylist)
print(mypd_series)
