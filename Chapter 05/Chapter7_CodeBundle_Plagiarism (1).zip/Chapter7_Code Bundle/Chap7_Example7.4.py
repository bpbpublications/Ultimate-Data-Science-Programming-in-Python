import pandas as mypd
# creating a Pandas Series from a scalar value
myseries = mypd.Series(10, index = [1,2,3,4])
print(myseries)